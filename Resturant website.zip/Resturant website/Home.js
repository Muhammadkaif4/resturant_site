window.onclick = () => {

}